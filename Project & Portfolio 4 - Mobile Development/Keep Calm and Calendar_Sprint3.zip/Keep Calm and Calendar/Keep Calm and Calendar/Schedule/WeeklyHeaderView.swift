//
//  WeeklyHeaderView.swift
//  Keep Calm and Calendar
//
//  Created by Johnny Mack on 10/2/18.
//  Copyright © 2018 John Mack. All rights reserved.
//

import UIKit

class WeeklyHeaderView: UITableViewHeaderFooterView {
    
    
    
    // MARK: - UI Outlets
    @IBOutlet weak var headerTitleLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var yearLabel: UILabel!
}
