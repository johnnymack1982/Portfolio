﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_4
{
    class Program
    {
        static void Main(string[] args)
        {
            //Instantiate new instance of Program class for use in calling non-static custom methods
            Program instance = new Program();

            //While this boolean evaluates to true, the program will continue to run
            bool running = true;

            //Instantiate a new dictionary to store colors and facts in.
            Dictionary<string, List<string>> colorDictionary = instance.PopulateDictionary();

            //Customize console background and text colors
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;

            //While the program is running, this code will continue to execute
            while (running)
            {
                Console.Clear();

                Console.WriteLine("EXERCISE 4: Color Dictionary Lookup");

                Console.WriteLine("\nWelcome! Select one of the colors below and we'll give you some interesting facts you may not have known!\n" +
                    "\n1) Red" +
                    "\n2) Orange" +
                    "\n3) Yellow" +
                    "\n4) Green" +
                    "\n5) Blue" +
                    "\n6) Indigo" +
                    "\n7) Violet" +
                    "\n8) Exit");

                //Collect user input and validate that it is a valid string
                string input = Validation.GetString("\nPlease make a selection: ");

                //Initialize a new string variable to store user's color choice and set it to null
                string colorChoice = null;

                //Determine how to proceed based on user's input
                switch (input.ToLower())
                {
                    //If user selected option one, this block of code will run
                    case "1":
                    case "red":
                        {
                            colorChoice = "red";
                        }
                        break;

                    //If user selected option two, this block of code will run
                    case "2":
                    case "orange":
                        {
                            colorChoice = "orange";
                        }
                        break;

                    //If user selected option three, this block of code will run
                    case "3":
                    case "yellow":
                        {
                            colorChoice = "yellow";
                        }
                        break;

                    //If user selected option four, this block of code will run
                    case "4":
                    case "green":
                        {
                            colorChoice = "green";
                        }
                        break;

                    //If user selected option five, this block of code will run
                    case "5":
                    case "blue":
                        {
                            colorChoice = "blue";
                        }
                        break;

                    //If use selected option six, this block of code will run
                    case "6":
                    case "indigo":
                        {
                            colorChoice = "indigo";
                        }
                        break;

                    //If user selected option seven, this block of code will run
                    case "7":
                    case "violet":
                        {
                            colorChoice = "violet";
                        }
                        break;

                    //If user selected option eight, the program will exit
                    case "8":
                    case "exit":
                        {
                            running = false;
                        }
                        break;
                }

                if (running)
                {
                    Console.Clear();

                    Console.WriteLine($"EXERCISE 4: Color Dictionary Lookup - {colorChoice.ToUpper()}");

                    //Call custom ColorFacts method to display facts for the user's chosen color
                    instance.DisplayColorFacts(colorDictionary, colorChoice);
                }
           
                //Waits for the user to press any key before continuing
                Utility.PauseBeforeContinuing();
            }
        }

        //Populates the dictionary with color names and three facts assocaited with each color
        public Dictionary<string, List<string>> PopulateDictionary()
        {
            //Initialize a new dictionary to add colors and facts to
            Dictionary<string, List<string>> colorDictionary = new Dictionary<string, List<string>>();

            //Initialize a new list to add facts to
            List<string> factsToAdd = new List<string>();

            //Add RED as a key in the dictionary
            colorDictionary.Add("red", null);

            //Add three facts to facts list
            factsToAdd.Add("Red also means \"Beautiful\" in Russian.");
            factsToAdd.Add("The word \"ruby\" comes from the Latin word, rubes, which means \"red.\"");
            factsToAdd.Add("Red doesn't actually make bulls angry. They are color blind.");

            //Add facts list to RED key in the dictionary
            colorDictionary["red"] = factsToAdd;

            //Reset the list to avoid adding incorrect facts to a color
            factsToAdd = new List<string>();

            //Add ORANGE as a key in the dictionary
            colorDictionary.Add("orange", null);

            //Add three facts to facts list
            factsToAdd.Add("The blood in the movie, 'Sweeny Todd,' had to be orange to render properly on the de-saturated color film.");
            factsToAdd.Add("Nobility were the only ones in the Elizabethine Era who were allowed to wear orange.");
            factsToAdd.Add("An orange vehicle means you are a trendy and fun loving person.");

            //Add facts list to ORANCE in the dictionary
            colorDictionary["orange"] = factsToAdd;

            //Reset the list to avoid adding incorrect facts to a color
            factsToAdd = new List<string>();

            //Add YELLOW as a key in the dictionary
            colorDictionary.Add("yellow", null);

            //Add three facts to facts list
            factsToAdd.Add("In Japan, yellow is the color of courage.");
            factsToAdd.Add("In Egypt, yellow is the color of mourning.");
            factsToAdd.Add("In American slang, a coward is called a \"yellow belly.\"");

            //Add facts list to YELLOW in the dictionary
            colorDictionary["yellow"] = factsToAdd;

            //Reset the list to avoid adding incorrect facts to a color
            factsToAdd = new List<string>();

            //Add GREEN as a key in the dictionary
            colorDictionary.Add("green", null);

            //Add three facts to the facts list
            factsToAdd.Add("Green is the color used in night-vision goggles because the human eye is capable of seeing the most shades of this color.");
            factsToAdd.Add("Green is the national color of Ireland.");
            factsToAdd.Add("Suicides dropped by 34% when London's Blafriar Bridge was painted green.");

            //Add facts list to GREEN in the dictionary
            colorDictionary["green"] = factsToAdd;

            //Reset the list to avoid adding incorrect facts to a color
            factsToAdd = new List<string>();

            //Add BLUE as a key in the dictionary
            colorDictionary.Add("blue", null);
            
            //Add three facts to the facts list
            factsToAdd.Add("Blue is commonly used in diet plates, because the color makes eating unappealing.");
            factsToAdd.Add("Blue can help you stay calm by regulating your heartbeat and breathing.");
            factsToAdd.Add("Blue pigments are so rare in nature, it used to be reserved only for the wealthy and powerful.");

            //Add facts to BLUE in the dictionary
            colorDictionary["blue"] = factsToAdd;

            //Reset the list to avoid adding incorrect facts to a color
            factsToAdd = new List<string>();

            //Add INDIGO as a key in the dictionary
            colorDictionary.Add("indigo", null);

            //Add three facts to the facts list
            factsToAdd.Add("Indigo represents religion, spirituality, sorcery, and intuition.");
            factsToAdd.Add("In the Hindu religion, ingigo represents the 6th chakra.");
            factsToAdd.Add("Indigo was the name of a character in Rainbow Bright.");

            //Add facts list to INDIGO in the dictionary
            colorDictionary["indigo"] = factsToAdd;

            //Reset the list to avoid adding incorrect facts to a color
            factsToAdd = new List<string>();

            //Add VIOLET as a key in the dictionary
            colorDictionary.Add("violet", null);

            //Add three facts to the facts list
            factsToAdd.Add("Carrots used to be violet, and not orange.");
            factsToAdd.Add("Porphyrophobia is fear of the color violet.");
            factsToAdd.Add("Purple (or Violet Day) Day is celebrated on March 26.");

            //Add facts list to VIOLET in the dictionary
            colorDictionary["violet"] = factsToAdd;

            //Reset the list to avoid adding incorrect facts to a color
            factsToAdd = new List<string>();

            //Return populated dictionary to main method
            return colorDictionary;
        }

        //Displays facts related to the color the user has chosen
        public void DisplayColorFacts(Dictionary<string, List<string>> colorDictionary, string colorChoice)
        {
            //Keeps track of line number in output
            int lineNumber = 1;

            //For each fact associated with the user's chosen color, repeat this code.
            foreach (string fact in colorDictionary[colorChoice])
            {
                //Display the current line number and the current fact in the list
                Console.WriteLine($"\n{lineNumber}) {fact}");

                //Increase the line number for the next fact
                lineNumber++;
            }
        }
    }
}
