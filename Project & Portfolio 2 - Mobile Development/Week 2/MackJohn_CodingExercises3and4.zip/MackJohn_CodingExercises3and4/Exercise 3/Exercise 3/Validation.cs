﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_3
{
    class Validation
    {

        //Collects and validates integer based input from the user
        public static int GetInt(int min, int max, string message = "Enter an integer: ")
        {
            int validatedInt;
            string input = null;

            do
            {
                Console.Write(message);
                input = Console.ReadLine();
            }
            while (!(Int32.TryParse(input, out validatedInt) && (validatedInt >= min && validatedInt <=max)));

            return validatedInt;
        }

        //Collects and validates string based input from the user
        public static string GetString(string message = "Please enter a string: ")
        {
            string input = null;

            do
            {
                Console.Write(message);
                input = Console.ReadLine();
            }
            while (string.IsNullOrWhiteSpace(input));

            return input;
        }

        //Collects and validates double based input form the user
        public static double GetDouble(double min, double max, string message = "Enter an double: ")
        {
            double validatedDouble;
            string input = null;

            do
            {
                Console.Write(message);
                input = Console.ReadLine();
            }
            while (!(double.TryParse(input, out validatedDouble) && (validatedDouble >= min && validatedDouble <= max)));

            return validatedDouble;
        }
    }
}
