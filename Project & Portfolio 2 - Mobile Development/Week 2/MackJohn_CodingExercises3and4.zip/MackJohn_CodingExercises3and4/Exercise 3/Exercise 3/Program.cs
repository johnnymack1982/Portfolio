﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_3
{
    class Program
    {
        static void Main(string[] args)
        {
            //Instantiate an instance of the Program class for use in calling non-static custom methods
            Program instance = new Program();

            //Instantiate a list of Students to be populated by the custom PopulateStudents method
            List<Student> students = instance.PopulateStudents();

            //While this boolean is true, the program will continue to run
            bool running = true;

            //Customize background and text colors
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;

            //While the program is running, the following code will continue to execute
            while (running)
            {
                Console.Clear();

                Console.WriteLine("EXERCISE 3: Calculate Grades");

                Console.WriteLine("\nWelcome, Administrator...");

                Console.WriteLine("\n1) View Students" +
                    "\n2) View Student GPA" +
                    "\n3) Update Student Grade" +
                    "\n4) Exit");

                //Collect user input to determine what code will run next
                string input = Validation.GetString("\nPlease make a selection: ");

                //Determines where to go next, based on user input
                switch (input.ToLower())
                {
                    //If user selects the first option, run this block of code
                    case "1":
                    case "view students":
                        {
                            Console.Clear();

                            Console.WriteLine("VIEW STUDENTS\n");

                            //Call custom DisplayStudents method to display the list of students
                            instance.DisplayStudents(students);

                            Utility.PauseBeforeContinuing();
                        }
                        break;

                    //If user selects the second option, run this block of code
                    case "2":
                    case "view student gpa":
                        {
                            Console.Clear();

                            Console.WriteLine("VIEW STUDENT GPA\n");

                            //Call custom DisplayStudents method to display the list of students
                            instance.DisplayStudents(students);

                            //Collect user input to determine which student information to display
                            int studentInput = Validation.GetInt(1, students.Count, $"\nPlease make a selection (1 - {students.Count}): ");

                            Console.Clear();

                            Console.WriteLine($"VIEW STUDENT GPA: {students[studentInput - 1].FirstName} {students[studentInput - 1].LastName}");

                            //Call custom DisplayGPA method to display selected student's grade and GPA information
                            instance.DisplayGPA(students[studentInput - 1]);

                            Utility.PauseBeforeContinuing();
                        }
                        break;

                    //If user selects the third option, run this block of code
                    case "3":
                    case "Update Student Grade":
                        {
                            Console.Clear();

                            Console.WriteLine("UPDATE STUDENT GRADE\n");

                            //Call custom DisplayStudent method to display list of students
                            instance.DisplayStudents(students);

                            //Collect user input to determine which student to change grades for
                            int studentInput = Validation.GetInt(1, students.Count, $"\nPlease make a selection (1 - {students.Count}): ");

                            Console.Clear();

                            Console.WriteLine($"UPDATE STUDENT GRADE: {students[studentInput - 1].FirstName} {students[studentInput - 1].LastName}\n");

                            //Call custom DisplayCourses method to show list of courses to select from
                            instance.DisplayCourses(students[studentInput - 1]);

                            //Collect user input to determine which course to change grade for
                            int courseInput = Validation.GetInt(1, students[studentInput - 1].Courses.Count, $"\nPlease make a selection (1 - {students[studentInput - 1].Courses.Count}): ");

                            Console.Clear();

                            Console.WriteLine($"UPDATE STUDENT GRADE: {students[studentInput - 1].FirstName} {students[studentInput - 1].LastName} - {students[studentInput - 1].Courses[courseInput - 1].Name}\n");

                            //Collect input to change grade for the selected student and course
                            students[studentInput - 1].Courses[courseInput - 1].Grade = Validation.GetDouble(1, 100, $"Please enter the student's new grade for this course (1.00 - 100.00): ");

                            Console.Clear();

                            Console.WriteLine($"UPDATE STUDENT GRADE: {students[studentInput - 1].FirstName} {students[studentInput - 1].LastName} - {students[studentInput - 1].Courses[courseInput - 1].Name}\n");

                            Console.WriteLine($"{students[studentInput - 1].FirstName}'s grade in {students[studentInput - 1].Courses[courseInput - 1].Name} has been updated " +
                                $"to: {students[studentInput - 1].Courses[courseInput - 1].Grade.ToString("0.00")}");

                            Utility.PauseBeforeContinuing();
                        }
                        break;

                    //If the user selects the forth option, run this block of code
                    case "4":
                    case "exit":
                        {
                            //Exits the program
                            running = false;

                            Utility.PauseBeforeContinuing();
                        }
                        break;
                }
            }
        }

        //Populate the list of students with hard-coded names
        private List<Student> PopulateStudents()
        {
            List<Student> students = new List<Student>();

            students.Add(new Student("Johnny", "Daniel"));
            students.Add(new Student("Ashleigh", "Jane"));
            students.Add(new Student("Brelynn", "Carolina"));
            students.Add(new Student("Myra", "Annaleigh"));
            students.Add(new Student("Molly", "May"));

            return students;
        }

        //Display current list of students
        private void DisplayStudents(List<Student> students)
        {
            //Initialize an integer to keep track of current line number to be displayed in list of students
            int lineNumber = 1;

            //Repeat this block of code for every student in the list of students
            foreach (Student student in students)
            {
                //Display the first and last name of the current student in the list
                Console.WriteLine($"{lineNumber}) {student.FirstName} {student.LastName}");

                //Increase line number for next line
                lineNumber++;
            }
        }

        //Display grades for each course and overall GPA for selected student
        private void DisplayGPA(Student student)
        {
            //Initialize a grade point at a value of 0, to be increased with each course, depending on number grade
            double gradePoint = 0;

            //Initialize a grade point average at a value of 0, to be calculated once all course grade points have been added up
            double gradePointAverage = 0;

            //Initialize a null letter grade to be determined and displayed depending on the grade value for the current class
            string letterGrade = null;

            //For each course the student is attending, run the following block of code
            foreach (Course course in student.Courses)
            {
                //Display course name and grade
                Console.WriteLine($"\n{course.Name}");
                Console.WriteLine($"\tGrade: {course.Grade.ToString("0.00")}");

                //If grade is 89.5 or higher, run this block of code
                if (course.Grade >= 89.5)
                {
                    letterGrade = "A";
                    gradePoint += 4.0;
                    Console.WriteLine("\tClass GPA: 4.00");

                }

                //If grade is between 79.5 and 89.4, run this block of code
                else if (course.Grade >= 79.5 && course.Grade <= 89.4)
                {
                    letterGrade = "B";
                    gradePoint += 3.0;
                    Console.WriteLine("\tClass GPA: 3.00");
                }

                //If grade is between 72.5 and 79.4, run this block of code
                else if (course.Grade >= 72.5 && course.Grade <= 79.4)
                {
                    letterGrade = "C";
                    gradePoint += 2.0;
                    Console.WriteLine("\tClass GPA: 2.00");
                }

                //If grade is between 69.5 and 72.4, run this block of code
                else if (course.Grade >= 69.5 && course.Grade <= 72.4)
                {
                    letterGrade = "D";
                    gradePoint += 1.0;
                    Console.WriteLine("\tClass GPA: 1.00");
                }

                //If grade is below 69.5, run this block of code
                else
                {
                    letterGrade = "F";
                    gradePoint += 0.0;
                    Console.WriteLine("\tClass GPA: 0.00");
                }

                Console.WriteLine($"\tLetter Grade: {letterGrade}");
            }

            //GPA is equal to the toal of all class grade points, divided by the number of courses the student is attending
            gradePointAverage = gradePoint / student.Courses.Count;

            Console.WriteLine($"\nTotal GPA: {gradePointAverage.ToString("0.00")}");
        }

        //Displays the courses for the currently selected student
        public void DisplayCourses(Student student)
        {
            int lineNumber = 1;

            //Displauy each course for the currently selected student
            foreach (Course course in student.Courses)
            {
                Console.WriteLine($"{lineNumber}) {course.Name}");
                lineNumber++;
            }
        }
    }
}
