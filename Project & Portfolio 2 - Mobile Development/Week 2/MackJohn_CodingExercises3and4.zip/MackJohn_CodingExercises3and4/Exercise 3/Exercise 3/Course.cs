﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_3
{
    class Course
    {
        //Initialize a private name field
        private string _name;

        //Initialize a private grade field
        private double _grade;

        //Getter / setter for name field
        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        //Getter / setter for grade field
        public double Grade
        {
            get
            {
                return _grade;
            }

            set
            {
                _grade = value;
            }
        }


        //Course class constructor method
        public Course(string name, double grade)
        {
            _name = name;
            _grade = grade;
        }
    }
}
