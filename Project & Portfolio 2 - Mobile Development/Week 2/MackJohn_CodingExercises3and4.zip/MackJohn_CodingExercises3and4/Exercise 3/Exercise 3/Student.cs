﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_3
{
    class Student
    {
        //Private field for first name
        private string _firstName;

        //Private field for last name
        private string _lastName;

        //Private field for list of courses the student is in
        private List<Course> _courses;

        //Getter / setter for first name field
        public string FirstName
        {
            get
            {
                return _firstName;
            }

            set
            {
                _firstName = value;
            }
        }

        //Getter / setter for last name field
        public string LastName
        {
            get
            {
                return _lastName;
            }

            set
            {
                _lastName = value;
            }
        }

        //Getter / setter for list of courses field
        public List<Course> Courses
        {
            get
            {
                return _courses;
            }

            set
            {
                _courses = value;
            }
        }

        //Constructor method for student class
        public Student(string firstName, string lastName)
        {
            _firstName = firstName;
            _lastName = lastName;
            _courses = PopulateCourses();
        }

        //Custom method to populate courses for each student
        private List<Course> PopulateCourses()
        {
            //Initialize new list of courses
            List<Course> courses = new List<Course>();

            //Initialize random variable to randomly generate grades for each class
            Random randomGrade = new Random();

            //Adds a new class for the student and randomly generates a grade between 50 and 100
            courses.Add(new Course("History of American Eagle", randomGrade.Next(50, 100)));

            //If the grade is less than 100, add a decimal value to the grade
            if (courses[0].Grade < 100)
            {
                //Randomly generates a decimal value to add to the grade
                courses[0].Grade += randomGrade.NextDouble();
            }

            //Adds a new class for the student and randomly generates a grade between 60 and 100
            courses.Add(new Course("The Rise of the Gap", randomGrade.Next(60, 100)));

            //If the grade is less than 100, add a decimal value to the grade
            if (courses[1].Grade < 100)
            {
                //Randomly generates a decimal value to add to the grade
                courses[1].Grade += randomGrade.NextDouble();
            }

            //Adds a new class for the student and randomly generates a grade between 70 and 100
            courses.Add(new Course("Theory of Aeropostle", randomGrade.Next(70, 100)));

            //If the grade is less than 100, add a decimal value to the grade
            if (courses[2].Grade < 100)
            {
                //Randomly generates a decimal value to add to the grade
                courses[2].Grade += randomGrade.NextDouble();
            }

            //Adds a new class for the student and randomly generates a grade between 60 and 100
            courses.Add(new Course("The Rapid Success of Express", randomGrade.Next(60, 100)));

            //If the grade is less than 100, add a decimal value to the grade
            if (courses[3].Grade < 100)
            {
                //Randomly generates a decimal value to add to the grade
                courses[3].Grade += randomGrade.NextDouble();
            }

            //Adds a new class for the student and randomly generates a grade between 50 and 100
            courses.Add(new Course("The Dirty History of Levi's", randomGrade.Next(50, 100)));

            //If the grade is less than 100, add a decimal value to the grade
            if (courses[4].Grade < 100)
            {
                //Randomly generates a decimal value to add to the grade
                courses[4].Grade += randomGrade.NextDouble();
            }

            return courses;
        }
    }
}
