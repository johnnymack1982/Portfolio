﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create instance variable to call custom methods
            Program instance = new Program();

            //Create new list variable to store list of 20 clothing brands
            List<string> itemList = new List<string>();

            //Populate itemList with 20 clothing brands
            itemList = instance.PopulateList(itemList);

            //Create custom color scheme for console output
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;

            //Declare variable to keep program running as long as the value is true
            bool running = true;

            //While the program is running, continue to execute the following code
            while (running)
            {
                //Clear the console for better readability
                Console.Clear();

                //Display user menu
                Console.WriteLine("CODE EXERCISE 1: CLOTHING BRANDS");

                Console.WriteLine("\n1) Display list of items" +
                    "\n2) Alphabatize list in ascending order (A-Z)" +
                    "\n3) Alphabatize list in descending order (Z-A)" +
                    "\n4) Remove random items one at a time until list is empty" +
                    "\n5) Exit");

                //Accept and validate user input
                string input = Validation.GetString("\nPlease make a selection: ");

                //Compare user input to available options and react accordingly
                switch (input.ToLower())
                {
                    //If user selects first option, run the following code
                    case "1":
                    case "display list of items":
                        {
                            Console.Clear();

                            Console.WriteLine("DISPLAY LIST OF ITEMS");

                            //Call custom method to display current list of clothing items
                            instance.DisplayList(itemList);

                            Utility.PauseBeforeContinuing();
                        }
                        break;

                    //If user selects second option, run the following code
                    case "2":
                    case "alphabatize list in ascending order":
                    case "alphabatize list in ascending order (a-z)":
                        {
                            //Sort list in alphabetical order
                            itemList.Sort();

                            Console.Clear();

                            Console.WriteLine("ALPHABATIZE LIST IN ASCENDING ORDER (A-Z)");

                            //Call custom method to display list of items
                            instance.DisplayList(itemList);

                            Utility.PauseBeforeContinuing();
                        }
                        break;

                    //If user selects third option, run the following code
                    case "3":
                    case "alphabatize list in descending order":
                    case "alphabatize list in descending order (z-a)":
                        {
                            //Sort list in alphabetical order
                            itemList.Sort();

                            //Reverse order of list so it is sorted in descending order
                            itemList.Reverse();

                            Console.Clear();

                            Console.WriteLine("ALPHABATIZE LIST IN ASCENDING ORDER (A-Z)");

                            //Call custom method to display list in its current state
                            instance.DisplayList(itemList);

                            Utility.PauseBeforeContinuing();
                        }
                        break;

                    //If user selects fourth option, run the following code
                    case "4":
                    case "remove random items one at a time until list is empty":
                        {
                            //Call custom method to remove one randomly selected item until the list is empty
                            itemList = instance.RandomDelete(itemList);
                        }
                        break;

                    //If user selects fifth option, exit the program
                    case "5":
                    case "exit":
                        {
                            running = false;

                            Utility.PauseBeforeContinuing();
                        }
                        break;

                }
            }
        }

        //Populate itemList with 20 clothing brands and return to main method
        public List<string> PopulateList(List<string> itemList)
        {
            itemList.Add("Joe Fresh");
            itemList.Add("Cabrini Sportswear");
            itemList.Add("WoodWood");
            itemList.Add("Bench");
            itemList.Add("Mavi Jeans");
            itemList.Add("Kookai");
            itemList.Add("Mandarina Duck");
            itemList.Add("SABA");
            itemList.Add("Louis Philippe");
            itemList.Add("Polly Flinders");
            itemList.Add("Prada");
            itemList.Add("Express");
            itemList.Add("Goochie");
            itemList.Add("American Eagle");
            itemList.Add("The Buckle");
            itemList.Add("Belk");
            itemList.Add("FiveFour");
            itemList.Add("Old Navy");
            itemList.Add("Gap");
            itemList.Add("Levi's");

            return itemList;
        }

        //Displays the list of items in its current state
        public void DisplayList(List<string> itemList)
        {
            //Declare integer to track number of the current item being printed to the string
            int lineNumber = 1;

            //Display a blank line
            Console.WriteLine();

            //Cycle through each index in the list and print the associated value, along with the current lineNumber
            foreach (string item in itemList)
            {
                Console.WriteLine($"{lineNumber}) {item}");

                //Increase current line number
                lineNumber++;
            }
        }

        //Deletes one randomly selected item from the list until there are none left
        public List<string> RandomDelete(List<string> itemList)
        {
            //Declare a variable to store a randomly generated number
            Random random = new Random();
            int randomIndex = 0;

            //While the list is not empty, run this code
            while (itemList.Count != 0)
            {
                //Generate a random number between 0 and the last index of the list
                randomIndex = random.Next(0, itemList.Count - 1);

                Console.Clear();

                Console.WriteLine("REMOVE RANDOM ITEMS ONE AT A TIME UNTIL LIST IS EMPTY");

                //Let the user know which random item is being removed
                Console.WriteLine($"\nRemoved {itemList[randomIndex]} from the list.");

                //Removes item from the list at the index matching the randomly generated number
                itemList.RemoveAt(randomIndex);

                //If the list is empty, let the user know
                if (itemList.Count == 0)
                {
                    Console.WriteLine("\nAll items have been removed");
                }

                //If the list is not empty, display the list in its current state
                else
                {
                    Console.WriteLine("\nREMAINING ITEMS:");

                    int lineNumber = 1;

                    foreach (string item in itemList)
                    {
                        Console.WriteLine($"\t{lineNumber}) {item}");
                        lineNumber++;
                    }
                }

                Utility.PauseBeforeContinuing();
            }

            return itemList;
        }
    }
}
