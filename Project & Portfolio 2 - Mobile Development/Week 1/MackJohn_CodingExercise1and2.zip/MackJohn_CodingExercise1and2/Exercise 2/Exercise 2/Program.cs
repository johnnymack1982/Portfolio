﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create new instance of program for use when calling custom methods
            Program instance = new Program();

            //Create new list variable to store list of available options
            List<string> itemList = new List<string>();

            //Populate list with the choices the user will select from
            itemList = instance.PopulateList(itemList);

            //Set custom console and text colors
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;

            Console.Clear();

            Console.WriteLine("EXERCISE 2: Guess the Clothing Brand");

            Console.WriteLine("\nWelcome! In this exercise, we will present you with a list of 20 clothing brands." +
                "\nYou will then be given a series of clues and asked to guess what the clothing brand is after each clue." +
                "\nAre you ready?");

            Utility.PauseBeforeContinuing();

            //Used in the following while loop to determine whether or not the program should continue running
            bool correct = false;

            //Determines which clue sequence to execute
            int attemptNumber = 1;

            //While the user's guess is incorrect, the following code will continue to run
            while (correct == false)
            {
                Console.Clear();

                Console.WriteLine("EXERCISE 2: Guess the Clothing Brand\n");

                instance.DisplayList(itemList);

                switch (attemptNumber)
                {
                    case 1:
                        {
                            Console.WriteLine("\nClue #1: This clothing brand is most popular among young adults.");

                            //Removes the last item in the list
                            itemList.RemoveAt(itemList.Count - 1);
                        }
                        break;

                    case 2:
                        {
                            Console.WriteLine("\nClue #2: This clothing brand is normally only sold in malls.");

                            Console.WriteLine("\nRemoving one incorrect answer from the list. You're welcome!");

                            //removes the first item in the list
                            itemList.RemoveAt(0);
                        }
                        break;

                    case 3:
                        {
                            Console.WriteLine("\nClue #3: Expect to pay top dollar for this clothing brand.");

                            Console.WriteLine("\nRemoving one incorrect answer from the list. You're welcome!");

                            //Removes the last item in the list
                            itemList.RemoveAt(itemList.Count - 1);
                        }
                        break;

                    case 4:
                        {
                            Console.WriteLine("\nClue #4: This clothing brand is popular among young professionals because of their dress clothes.");

                            Console.WriteLine("\nRemoving one incorrect answer from the list. You're welcome!");

                            //Removes the first item in the list
                            itemList.RemoveAt(0);
                        }
                        break;

                    case 5:
                        {
                            Console.WriteLine("\nClue #5: Don't expect to find a lot of casual clothing here.");

                            Console.WriteLine("\nRemoving one incorrect answer from the list. You're welcome!");

                            //Removes the last item in the list
                            itemList.RemoveAt(itemList.Count - 1);
                        }
                        break;

                    case 6:
                        {
                            Console.WriteLine("\nClue #6: Women can find designer clothing here, but not accessories or purses.");

                            Console.WriteLine("\nRemoving one incorrect answer from the list. You're welcome!");

                            //Removes the first item in the list
                            itemList.RemoveAt(0);
                        }
                        break;

                    case 7:
                        {
                            Console.WriteLine("\nClue #7: FASTER IS BETTER!");
                        }
                        break;

                    //This block will continue to run after all other clues have been exausted until the user enters the correct answer
                    default:
                        {
                            //If there is more than one item in the list, this code will run
                            if (itemList.Count > 1)
                            {
                                //If the correct answer is at the first index of the list, this code will run
                                if (itemList.IndexOf("Express") == 0)
                                {
                                    Console.WriteLine("\nRemoving one incorrect answer from the list. You're welcome!");

                                    //Remove the last item in the list
                                    itemList.RemoveAt(itemList.Count - 1);
                                }

                                //If the correct answer is not at the first index of the list, this code will run
                                else
                                {
                                    Console.WriteLine("\nRemoving one incorrect answer from the list. You're welcome!");

                                    //Removes the first item in the list
                                    itemList.RemoveAt(0);
                                }
                            }
                        }
                        break;
                }

                string input = Validation.GetString("\nEnter your guess and see if you're right (Type 'Exit' to leave the program): ");

                //Call custom method to check the user's input and see if they guessed right
                correct = instance.CheckAnswer(itemList, input);

                //Increases the attempt number to proceed to the next clue in the sequence
                attemptNumber++;
            }
        }

        //Populates initial list with choices for user to select from
        public List<string> PopulateList(List<string> itemList)
        {
            itemList.Add("WoodWood");
            itemList.Add("Bench");
            itemList.Add("Kookai");
            itemList.Add("SABA");
            itemList.Add("Prada");
            itemList.Add("Express");
            itemList.Add("Goochie");
            itemList.Add("Belk");
            itemList.Add("FiveFour");
            itemList.Add("Gap");
            itemList.Add("Levi's");

            return itemList;
        }

        //Displays the list to the user in its current state
        public void DisplayList(List<string> itemList)
        {
            int lineNumber = 1;

            //Prints each item in the list to the screen
            foreach (string item in itemList)
            {
                Console.WriteLine($"{lineNumber}) {item}");

                lineNumber++;
            }
        }

        //Checks the user's input to see if they guessed correctly
        public bool CheckAnswer(List<string> itemList, string input)
        {
            //Set the initial value of the correct guess checker to false. This will be the default unless the input is found to be correct
            bool correct = false;

            //Selects the current index of the correct answer in the list
            int index = itemList.IndexOf("Express");

            //If the user's input matches the correct answer exactly, this code will execute
            if (input == itemList[index])
            {
                Console.Clear();

                Console.WriteLine("EXERCISE 2: Guess the Clothing Brand");

                Console.WriteLine("\nYou got it right! The program will now exit.");

                //Indicates that the user entered the correct answer
                correct = true;
            }

            //If the user entered the correct answer but did not capitalize it properly, let them know
            else if(input.ToLower() == itemList[index].ToLower())
            {
                Console.Clear();

                Console.WriteLine("EXERCISE 2: Guess the Clothing Brand");

                Console.WriteLine("\nSo close! Make sure you type the answer EXACTLY as it appears in the list of available options.");
            }

            //If the user asked to exit the program, this code will execute
            else if(input.ToLower() == "exit")
            {
                Console.Clear();

                Console.WriteLine("EXERCISE 2: Guess the Clothing Brand");

                Console.WriteLine("\nYou are now exiting the program.");

                Utility.PauseBeforeContinuing();

                Environment.Exit(0);
            }

            //If all other checks fail, inform the user that their answer is incorrect
            else
            {
                Console.Clear();

                Console.WriteLine("EXERCISE 2: Guess the Clothing Brand");

                Console.WriteLine("\nSorry. Try again!");
            }

            Utility.PauseBeforeContinuing();

            return correct;
        }
    }
}
