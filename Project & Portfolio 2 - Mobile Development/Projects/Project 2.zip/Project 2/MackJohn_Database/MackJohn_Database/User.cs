﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MackJohn_Database
{
    class User
    {
        private string _userEmail;
        private string _password;

        public string UserEmail
        {
            get
            {
                return _userEmail;
            }

            set
            {
                _userEmail = value;
            }
        }

        public string Password
        {
            get
            {
                return _password;
            }

            set
            {
                _password = value;
            }
        }

        public User(string userEmail, string password)
        {
            _userEmail = userEmail;
            _password = password;
        }
    }
}
