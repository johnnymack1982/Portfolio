﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MackJohn_Database
{
    class Validation
    {
        public static int GetInt(string message = "Enter an integer: ")
        {
            int validatedInt;
            string input = null;

            do
            {
                Console.Write(message);
                input = Console.ReadLine();
            }
            while (!Int32.TryParse(input, out validatedInt));

            return validatedInt;
        }

        public static int GetInt(int min, int max, string message = "Enter an integer: ")
        {
            int validatedInt;
            string input = null;

            do
            {
                Console.Write(message);
                input = Console.ReadLine();
            }
            while (!(Int32.TryParse(input, out validatedInt) && (validatedInt >= min && validatedInt <=max)));

            return validatedInt;
        }

        public static float GetFloat(string message = "Enter an float: ")
        {
            float validatedFloat;
            string input = null;

            do
            {
                Console.Write(message);
                input = Console.ReadLine();
            }
            while (!float.TryParse(input, out validatedFloat));

            return validatedFloat;
        }

        public static float GetFloat(float min, float max, string message = "Enter an float: ")
        {
            float validatedFloat;
            string input = null;

            do
            {
                Console.Write(message);
                input = Console.ReadLine();
            }
            while (!(float.TryParse(input, out validatedFloat) && (validatedFloat >= min && validatedFloat <= max)));

            return validatedFloat;
        }

        public static decimal GetDecimal(string message = "Enter an float: ")
        {
            decimal validatedDecimal;
            string input = null;

            do
            {
                Console.Write(message);
                input = Console.ReadLine();
            }
            while (!decimal.TryParse(input, out validatedDecimal));

            return validatedDecimal;
        }

        public static decimal GetDecimal(decimal min, decimal max, string message = "Enter an float: ")
        {
            decimal validatedDecimal;
            string input = null;

            do
            {
                Console.Write(message);
                input = Console.ReadLine();
            }
            while (!(decimal.TryParse(input, out validatedDecimal) && (validatedDecimal >= min && validatedDecimal <= max)));

            return validatedDecimal;
        }

        public static string GetString(string message = "Please enter a string: ")
        {
            string input = null;

            do
            {
                Console.Write(message);
                input = Console.ReadLine();
            }
            while (string.IsNullOrWhiteSpace(input));

            return input;
        }

        public static int IsInt(string isInt)
        {
            int validatedInt;
            if(int.TryParse(isInt, out validatedInt))
            {
                return validatedInt;
            }

            else
            {
                return -1;
            }
        }
    }
}
