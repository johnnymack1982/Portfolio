﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MackJohn_Database
{
    class Utility
    {
        public static void PauseBeforeContinuing()
        {
            Console.Write("\r\nPress any key to contine...");
            Console.ReadKey();
        }
    }
}
