﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace MackJohn_Database
{
    class Program
    {
        static void Main(string[] args)
        {
            bool running = true;
            Program instance = new Program();
            User currentUser = null;
            Baby currentBaby = null;

            string cs = @"server=172.16.73.1;userid=MackJohn;password=mack;database=MackJohn_Database; port=8889";

            MySqlConnection dbConnection = null;

            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;

            while (running)
            {
                Console.Clear();

                Console.WriteLine("FINAL PROJECT: Database Example");

                Console.WriteLine("\n1) New User" +
                    "\n2) Log In");

                string input = Validation.GetString("\nPlease make a selection: ");

                switch (input.ToLower())
                {
                    case "1":
                    case "new user":
                        {
                            Console.Clear();

                            Console.WriteLine("CREATE NEW USER");

                            string userEmail = Validation.GetString("\nPlease enter your email address: ");
                            string password = Validation.GetString("Please enter a password: ");

                            currentUser = new User(userEmail, password);

                            try
                            {
                                dbConnection = new MySqlConnection(cs);
                                dbConnection.Open();

                                string createUserEntry = $"insert into users (userEmail, password) values ('{userEmail}', '{password}');";
                                MySqlCommand cmd = new MySqlCommand(createUserEntry, dbConnection);
                                cmd.ExecuteReader();

                            }
                            catch (MySqlException ex)
                            {
                                Console.WriteLine("Error: {0}", ex.ToString());

                            }
                            finally
                            {

                                if (dbConnection != null)
                                {
                                    dbConnection.Close();
                                }

                            }

                            Console.Clear();

                            Console.WriteLine("CREATE NEW BABY");

                            string name = Validation.GetString("\nPlease enter your baby's name: ");
                            string DOB = Validation.GetString("Please enter your baby's date of birth: ");
                            string gender = Validation.GetString("Please enter your baby's gender (M / F): ");

                            while (gender.ToLower() != "m" && gender.ToLower() != "f")
                            {
                                gender = Validation.GetString("Please enter your baby's gender (M / F): ");
                            }

                            currentBaby = new Baby(name, DOB, gender);

                            try
                            {
                                dbConnection = new MySqlConnection(cs);
                                dbConnection.Open();

                                string createBabyEntry = $"insert into babies (userID, name, DOB, genderID) values (351, '{name}', CURRENT_DATE, '{gender.ToUpper()}');";
                                MySqlCommand cmd = new MySqlCommand(createBabyEntry, dbConnection);
                                cmd.ExecuteReader();

                            }
                            catch (MySqlException ex)
                            {
                                Console.WriteLine("Error: {0}", ex.ToString());

                            }
                            finally
                            {

                                if (dbConnection != null)
                                {
                                    dbConnection.Close();
                                }

                            }

                            Utility.PauseBeforeContinuing();
                        }
                        break;

                    case "2":
                    case "log in":
                        {
                            Console.Clear();

                            Console.WriteLine("LOG IN");

                            string userEmail = Validation.GetString("\nPlease enter your email address: ");
                            string password = Validation.GetString("Please enter a password: ");

                            currentUser = new User(userEmail, password);

                            try
                            {
                                dbConnection = new MySqlConnection(cs);
                                MySqlDataReader reader = null;
                                dbConnection.Open();

                                string logIn = $"select userEmail, password from users where userEmail = '{userEmail}' and password = '{password}';";
                                MySqlCommand cmd = new MySqlCommand(logIn, dbConnection);
                                reader = cmd.ExecuteReader();

                                while (reader.Read())
                                {
                                    Console.WriteLine($"\nLogged in: DB UserID = {reader.GetString(0)}");
                                }

                            }
                            catch (MySqlException ex)
                            {
                                Console.WriteLine("Error: {0}", ex.ToString());

                            }
                            finally
                            {

                                if (dbConnection != null)
                                {
                                    dbConnection.Close();
                                }

                            }

                            Utility.PauseBeforeContinuing();
                        }
                        break;
                }

                Console.Clear();

                Console.WriteLine("DISPLAY INFORMATION FROM BABIES TABLE");

                try
                {
                    dbConnection = new MySqlConnection(cs);
                    MySqlDataReader reader = null;
                    dbConnection.Open();

                    string babyInfo = $"select name, DOB, genderID from babies where babyID = 351;";
                    MySqlCommand cmd = new MySqlCommand(babyInfo, dbConnection);
                    reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        Console.WriteLine($"\nName: {reader.GetString(0)}" +
                            $"\nDOB: {reader.GetString(1)}" +
                            $"\nGender: {reader.GetString(2)}");
                    }

                }
                catch (MySqlException ex)
                {
                    Console.WriteLine("Error: {0}", ex.ToString());

                }
                finally
                {

                    if (dbConnection != null)
                    {
                        dbConnection.Close();
                    }

                }

                Console.WriteLine("\n1) Record Feeding" +
                    "\n2) Display Recent Feedings");

                input = Validation.GetString("\nEnter a selection: ");

                switch (input.ToLower())
                {
                    case "1":
                    case "record feeding":
                        {
                            Console.WriteLine("\nUser enters side." +
                                "\nUser enters start time." +
                                "\nUser enters stop time." +
                                "\nInformation entered into Feedings Table");

                            Utility.PauseBeforeContinuing();
                        }
                        break;

                    case "2":
                    case "display recent feedings":
                        {
                            try
                            {
                                dbConnection = new MySqlConnection(cs);
                                MySqlDataReader reader = null;
                                dbConnection.Open();

                                string feedingsInfo = $"select date, startTime, sideID, length from feedings where babyID = 352;";
                                MySqlCommand cmd = new MySqlCommand(feedingsInfo, dbConnection);
                                reader = cmd.ExecuteReader();

                                while (reader.Read())
                                {
                                    Console.WriteLine($"\nDate: {reader.GetString(0)}" +
                                        $"\nStart Time: {reader.GetString(1)}" +
                                        $"\nSide ID: {reader.GetString(2)}" +
                                        $"\nStop Time: {reader.GetString(3)}");
                                }

                            }
                            catch (MySqlException ex)
                            {
                                Console.WriteLine("Error: {0}", ex.ToString());

                            }
                            finally
                            {

                                if (dbConnection != null)
                                {
                                    dbConnection.Close();
                                }

                            }

                            Utility.PauseBeforeContinuing();
                        }
                        break;
                }
            }
        }
    }
}
