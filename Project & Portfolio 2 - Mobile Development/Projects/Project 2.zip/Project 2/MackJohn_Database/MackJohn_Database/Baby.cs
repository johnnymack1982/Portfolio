﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MackJohn_Database
{
    class Baby
    {
        private string _name;
        private string _DOB;
        private string _gender;

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        public string DOB
        {
            get
            {
                return _DOB;
            }

            set
            {
                _DOB = value;
            }
        }

        public string Gender
        {
            get
            {
                return _gender;
            }

            set
            {
                _gender = value;
            }
        }

        public Baby(string name, string DOB, string gender)
        {
            _name = name;
            _DOB = DOB;
            _gender = gender;
        }
    }
}
