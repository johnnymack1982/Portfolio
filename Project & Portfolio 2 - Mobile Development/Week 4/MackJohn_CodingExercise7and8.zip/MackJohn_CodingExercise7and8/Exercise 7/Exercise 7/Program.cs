﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_7
{
    class Program
    {
        static void Main(string[] args)
        {
            //Initialize a list to contain user input for adjectives
            List<string> adjectives = new List<string>();

            //Initialize a list to contain user input for nouns
            List<string> nouns = new List<string>();

            //Initialize a list to contain user input for past tense verbs
            List<string> pastTenseVerbs = new List<string>();

            //Iniitialize a list to contain user input for adverbs
            List<string> adverbs = new List<string>();

            //Initialize a variable to contain user input for a verb
            string verb = null;

            //Set custom background and text colors
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;

            //Prevents the program from continuing until the user enters a valid selection
            bool selectionMade = false;

            //This code will continue to execute until a valid selection is entered
            while (!selectionMade)
            {

                Console.Clear();

                Console.WriteLine("EXERCISE 7: Mad Libs Story");

                Console.WriteLine("\nHello! Let's play Mad Libs. I'm going to ask you to enter a series of words. Once we're done, I'll show you the story you helped to write.");

                //Collect user input and decide how to proceed
                string ready = Validation.GetString("Are you ready? (Yes / No): ");

                switch (ready.ToLower())
                {
                    //If the user is ready, the program will continue
                    case "yes":
                        {
                            selectionMade = true;
                        }
                        break;

                    //If the user doesn't want to play, the program will exit
                    case "no":
                        {
                            selectionMade = true;
                            Utility.PauseBeforeContinuing();
                            Environment.Exit(0);
                        }
                        break;

                    //Prevents the program from continuing until a valid selection has been made
                    default:
                        {
                            selectionMade = false;
                        }
                        break;
                }
            }

            Console.Clear();

            Console.WriteLine("EXERCISE 7: Mad Libs Story");

            Console.WriteLine("\nGreat! Next, I'm going to ask you to enter a series of words. Don't think too hard! Just enter the first word that comes to mind.");

            Utility.PauseBeforeContinuing();

            //This code will collect input from the user four times for the adverbs list.
            for (int i = 0; i < 4; i++)
            {
                Console.Clear();

                Console.WriteLine("EXERCISE 7: Mad Libs Story");

                //Prompt user for current adverb and add it to the list
                adjectives.Add(Validation.GetString($"\nPlease enter adjective {i + 1} of 4.\n" +
                    $"\nAn adjective is a word or phrase naming an attribute, added to or grammatically related to a noun to modify or describe it.\n" +
                    $"\nEnter your word now: "));
            }

            //This code will collect input from the user three times for the nouns list
            for (int i = 0; i < 3; i++)
            {
                Console.Clear();

                Console.WriteLine("EXERCISE 7: Mad Libs Story");

                //Prompt user for current noun and add it to the list
                nouns.Add(Validation.GetString($"\nPlease enter noun {i + 1} of 3.\n" +
                    $"\nA noun is a word (other than a pronoun) used to identify any of a class of people, places, or things common noun, or to name a particular one of these proper noun.\n" +
                    $"\nEnter your word now: "));
            }

            //This code will collect input from the user twice for the past tense verbs list
            for (int i = 0; i < 2; i++)
            {
                Console.Clear();

                Console.WriteLine("EXERCISE 7: Mad Libs Story");

                //Prompt the user for current past tense verb and add it to the list
                pastTenseVerbs.Add(Validation.GetString($"\nPlease enter past-tense verb {i + 1} of 2.\n" +
                    $"\nPast tense verbs refer to actions or events in the past.\n" +
                    $"\nEnter your word now: "));
            }

            //This code will collect input from the user twice for the adverbs list
            for (int i = 0; i < 2; i++)
            {
                Console.Clear();

                Console.WriteLine("EXERCISE 7: Mad Libs Story");

                //Prompt the user for the current adverb and add it to the list
                adverbs.Add(Validation.GetString($"\nPlease enter adverb {i + 1} of 2.\n" +
                    $"\nAn adverb is a word or phrase that modifies or qualifies an adjective, verb, or other adverb or a word group, expressing a relation of place, " +
                    $"\ntime, circumstance, manner, cause, degree, etc.\n" +
                    $"\nEnter your word now: "));
            }

            Console.Clear();

            Console.WriteLine("EXERCISE 7: Mad Libs Story");

            //Prompt user for the verb and store it in the verb variable
            verb = Validation.GetString($"\nPlease enter a verb\n" +
                $"\nA verb is a word used to describe an action, state, or occurrence.\n" +
                $"\nEnter your word now: ");

            Console.Clear();

            Console.WriteLine("EXERCISE 7: Mad Libs Story");

            Console.WriteLine("\nGreat job! Now, let's take a look at the story you helped to write!");

            Utility.PauseBeforeContinuing();

            Console.Clear();

            Console.WriteLine("EXERCISE 7: Mad Libs Story");

            //Print the story with the user's entered words. User input will be displayed in ALL CAPS
            Console.WriteLine($"\nToday I went to the zoo. I saw a {adjectives[0].ToUpper()} {nouns[0].ToUpper()} jumping up and down in its tree.\n" +
                $"\nHe {pastTenseVerbs[0].ToUpper()} {adverbs[0].ToUpper()} through the large tunnel that led to it's {adjectives[1].ToUpper()} {nouns[1].ToUpper()}. " +
                $"\nI got some peanuts and passed them through the cage to a gigantic gray {nouns[2].ToUpper()} towering above my head. Feeding that animal made me hungry.\n" +
                $"\nI went to get a {adjectives[2].ToUpper()} scoop of ice cream. It filled my stomach. Afterwards I had to {verb.ToUpper()} {adverbs[1].ToUpper()} to catch our bus.\n" +
                $"\nWhen I got home I {pastTenseVerbs[1].ToUpper()} my mom for a {adjectives[3].ToUpper()} day at the zoo.");

            Utility.PauseBeforeContinuing();
        }
    }
}
