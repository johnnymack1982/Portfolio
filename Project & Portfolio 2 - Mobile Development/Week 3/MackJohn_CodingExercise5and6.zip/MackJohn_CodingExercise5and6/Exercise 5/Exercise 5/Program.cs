﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_5
{
    class Program
    {
        static void Main(string[] args)
        {
            //Initialize an intance of the Program class to be used when calling custom methods
            Program instance = new Program();

            //While this boolean is true, the program will continue to run
            bool running = true;

            //This boolean will prevent the program from proceding until the user is ready to play
            bool readyToPlay = false;

            //Keeps track of player's selection during each round
            int playerTurn = 0;

            //Keeps track of computer's selection during each round
            int computerTurn = 0;

            //Keeps track of who won during each round
            int whoWon = 0;

            //Keeps track of how many times the player has won
            int playerWins = 0;

            //Keeps track of how many times the computer has won
            int computerWins = 0;

            //Keeps track of how many times the player and computer have tied
            int ties = 0;

            //Set custom background and text colors
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;

            //While the program is running, continue to run this code
            while (running)
            {
                //Do not proceed until the player is ready to proceed
                while (!readyToPlay)
                {
                    Console.Clear();

                    Console.WriteLine("EXERCISE 5: Rock, Paper, Scissors, Lizard, Spock");

                    Console.WriteLine("\nHello! Let's play a game of 'Rock, Paper, Scissors, Lizard, Spock." +
                        "\nIn this game, the rules are simple. Choose an object and see if you win. You'll play a total of 10 rounds per game.\n" +
                        "\nScissors cut paper and decapitates lizard." +
                        "\nPaper covers rock and disproves Spock." +
                        "\nRock crushes lizard and crushes scissors. " +
                        "\nLizard poisons Spock and eats paper." +
                        "\nSpock smashes scissors and vaporizes rock.");

                    //Collect input to determine if user is ready to continue
                    string ready = Validation.GetString("\nAre you ready to play? ('Yes' - 'No' - 'Exit'): ");

                    switch (ready.ToLower())
                    {
                        //If player is ready, the program will continue
                        case "yes":
                            {
                                readyToPlay = true;
                            }
                            break;

                        //If the player is not ready, the program will not continue
                        case "no":
                            {
                                readyToPlay = false;
                            }
                            break;

                        //If the computer chooses, the program will exit
                        case "exit":
                            {
                                readyToPlay = true;
                                running = false;
                                Utility.PauseBeforeContinuing();
                                Environment.Exit(0);
                            }
                            break;
                    }
                }

                //Keeps track of which of 10 rounds the player is on
                int round = 1;

                //Prevents the program from continuing until the user has made a valid selection
                bool selectionMade = false;

                //Continues to execute until the player has completed 10 rounds
                while (round < 11 || !selectionMade)
                {
                    Console.Clear();

                    Console.WriteLine("EXERCISE 5: Rock, Paper, Scissors, Lizard, Spock");

                    Console.WriteLine($"\nRound {round}");

                    Console.WriteLine("\n1) Rock" +
                        "\n2) Paper" +
                        "\n3) Scissors" +
                        "\n4) Lizard" +
                        "\n5) Spock" +
                        "\n6) Exit");

                    string input = Validation.GetString("\nPlease make a selection: ");

                    switch (input.ToLower())
                    {
                        //If the player selects option one, this code will execute
                        case "1":
                        case "rock":
                            {
                                playerTurn = 1;
                                Console.WriteLine("\nYou chose ROCK");
                                selectionMade = true;
                            }
                            break;

                        //If the player selects option two, this code will execute
                        case "2":
                        case "paper":
                            {
                                playerTurn = 2;
                                Console.WriteLine("\nYou chose PAPER");
                                selectionMade = true;
                            }
                            break;

                        //If the player selects option three, this code will execute
                        case "3":
                        case "scissors":
                            {
                                playerTurn = 3;
                                Console.WriteLine("\nYou chose SCISSORS");
                                selectionMade = true;
                            }
                            break;

                        //If the player selects option four, this code will execute
                        case "4":
                        case "lizard":
                            {
                                playerTurn = 4;
                                Console.WriteLine("\nYou chose LIZARD");
                                selectionMade = true;
                            }
                            break;

                        //If the player selects option five, this code will execute
                        case "5":
                        case "spock":
                            {
                                playerTurn = 5;
                                Console.WriteLine("\nYou chose SPOCK");
                                selectionMade = true;
                            }
                            break;

                        //If the player selects option six, this code will execute and the program will exit
                        case "6":
                        case "exit":
                            {
                                running = false;
                                selectionMade = true;
                                Utility.PauseBeforeContinuing();
                                Environment.Exit(0);
                            }
                            break;

                        //If the player has not made a valid selection, the program will not continue until they do
                        default:
                            {
                                selectionMade = false;
                            }
                            break;
                    }

                    //The following code will only execute if the player has made a valid selection
                    if (selectionMade)
                    {
                        //Calls a custom method to randomly generate the computer's selection
                        computerTurn = instance.ComputerTurn();

                        //Calls a custom method to compare player selection against the computer selection to determine a winner for the round
                        whoWon = instance.WhoWon(computerTurn, playerTurn);

                        //Tracks and displays computer vs player wins
                        switch (whoWon)
                        {
                            //If the round was a tie, this code will execute
                            case 0:
                                {
                                    //Record a tie on the scoreboard
                                    ties++;
                                    Console.WriteLine("\nTie!");
                                }
                                break;

                            //If the player won, this code will execute
                            case 1:
                                {
                                    //Record a player win on the scoreboard
                                    playerWins++;
                                    Console.WriteLine("\nPlayer wins!");
                                }
                                break;

                            //If the computer won, this code will execute
                            case 2:
                                {
                                    //Record a computer win on the scoreboard
                                    computerWins++;
                                    Console.WriteLine("\nComputer wins!");
                                }
                                break;
                        }

                        Utility.PauseBeforeContinuing();

                        //Increases the round number until 10 rounds have been played
                        round++;
                    }
                }

                Console.Clear();

                Console.WriteLine("EXERCISE 5: Rock, Paper, Scissors, Lizard, Spock");

                Console.WriteLine($"\nYou tied {ties} times." +
                    $"\nYou won {playerWins} times." +
                    $"\nYou lost {computerWins} times.");

                string playAgain = Validation.GetString("\nWould you like to play again? (Yes / No): ");

                //If the player chooses to play again, reset the scoreboard and round tracker
                if (playAgain.ToLower() == "yes")
                {
                    round = 1;
                    playerTurn = 0;
                    computerTurn = 0;
                    whoWon = 0;
                    playerWins = 0;
                    computerWins = 0;
                    ties = 0;
                }

                //If the player chooses not to play again, the program will exit
                else
                {
                    running = false;

                    Utility.PauseBeforeContinuing();
                }
            }
        }

        //Custom method to randomly generate the computer's selection during each round of play
        public int ComputerTurn()
        {
            //Keeps track of the computer's selection
            int computerTurn = 0;

            //Initalize a random number generator
            Random randomSelection = new Random();

            //Randomly select a choice for the computer
            computerTurn = randomSelection.Next(1, 5);

            switch (computerTurn)
            {
                //If the computer chose option one, this code will run
                case 1:
                    {
                        Console.WriteLine("Computer chose ROCK");
                    }
                    break;

                //If the computer chose option two, this code will execute
                case 2:
                    {
                        Console.WriteLine("Computer chose PAPER");
                    }
                    break;

                //If the computer chose option three, this code will execute
                case 3:
                    {
                        Console.WriteLine("Computer chose SCISSORS");
                    }
                    break;

                //If the computer chose option four, this code will execute
                case 4:
                    {
                        Console.WriteLine("Computer chose LIZARD");
                    }
                    break;

                //If the computer chose option five, this code will execute
                case 5:
                    {
                        Console.WriteLine("Computer chose SPOCK");
                    }
                    break;
            }

            //Returns the computer's selection to the main method
            return computerTurn;
        }

        //Custom method to determine the winner of each round
        public int WhoWon(int computerTurn, int playerTurn)
        {
            //Tracks the round winner
            int whoWon = 0;

            //If the computer and player made the same selection, the round is a tie
            if (playerTurn == computerTurn)
            {
                whoWon = 0;
            }

            //If the round is not a tie, determine who won
            else
            {
                switch (playerTurn)
                {
                    //If the player chose "rock"
                    case 1:
                        {
                            //If the computer chose "scissors" or "lizard", the player wins
                            if (computerTurn == 3 || computerTurn == 4)
                            {
                                whoWon = 1;
                            }

                            //Otherwise, the computer wins
                            else
                            {
                                whoWon = 2;
                            }
                        }
                        break;

                    //If the player chose "paper"
                    case 2:
                        {
                            //If the computer chose "rock" or "spock", the player wins
                            if (computerTurn == 1 || computerTurn == 5)
                            {
                                whoWon = 1;
                            }

                            //Otherwise, the computer wins
                            else
                            {
                                whoWon = 2;
                            }
                        }
                        break;

                    //If the player chose "scissors"
                    case 3:
                        {
                            //If the computer chose "paper" or "lizard", the player wins
                            if (computerTurn == 2 || computerTurn == 4)
                            {
                                whoWon = 1;
                            }

                            //Otherwise, the computer wins
                            else
                            {
                                whoWon = 2;
                            }
                        }
                        break;

                    //If the player chose "lizard"
                    case 4:
                        {
                            if(computerTurn == 2 || computerTurn == 5)
                            {
                                whoWon = 1;
                            }

                            else
                            {
                                whoWon = 2;
                            }
                        }
                        break;

                    //If the player chose "spock"
                    case 5:
                        {
                            //If the comnputer chose "rock" or "scissors", the player wins
                            if (computerTurn == 1 || computerTurn == 3)
                            {
                                whoWon = 1;
                            }

                            //Otherwise, the computer wins
                            else
                            {
                                whoWon = 2;
                            }
                        }
                        break;
                }
            }

            //Return the winning results to the main menu
            return whoWon;
        }
    }
}
