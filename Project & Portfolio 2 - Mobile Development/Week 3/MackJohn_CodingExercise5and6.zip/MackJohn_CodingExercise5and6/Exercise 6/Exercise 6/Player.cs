﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_6
{
    class Player
    {
        //Private fields for Player class
        private string _name;
        private List<Card> _hand;
        private int _score;

        //Getter and setter for _name field
        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        //Getter and setter for _hand field
        public List<Card> Hand
        {
            get
            {
                return _hand;
            }

            set
            {
                _hand = value;
            }
        }

        //Getter and setter for _score field
        public int Score
        {
            get
            {
                return _score;
            }

            set
            {
                _score = value;
            }
        }

        //Constructor method for Player class
        public Player(string name, List<Card> hand, int score)
        {
            _name = name;
            _hand = hand;
            _score = score;
        }
    }
}
