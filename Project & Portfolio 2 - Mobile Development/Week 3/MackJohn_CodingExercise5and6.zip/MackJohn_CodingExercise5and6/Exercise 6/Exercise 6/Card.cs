﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_6
{
    class Card
    {
        //Private fields for Card class
        private string _cardSuit;
        private string _cardValue;
        private int _scoreValue;

        //Getter and setter for _cardSuit
        public string CardSuit
        {
            get
            {
                return _cardSuit;
            }

            set
            {
                _cardSuit = value;
            }
        }

        //Getter and setter for _cardValue
        public string CardValue
        {
            get
            {
                return _cardValue;
            }

            set
            {
                _cardValue = value;
            }
        }

        //Getter and setter for _scoreValue
        public int ScoreValue
        {
            get
            {
                return _scoreValue;
            }

            set
            {
                _scoreValue = value;
            }
        }

        //Constructor method for Card class
        public Card(string cardSuit, string cardValue)
        {
            _cardValue = cardValue;
            _cardSuit = cardSuit;
            
            //_scoreValue is automatically calculated by the program
            _scoreValue = CalculateScore(_cardValue);
        }

        //Custom class to calculate each card's point value
        private int CalculateScore(string cardValue)
        {
            //Keeps track of current card's score
            int scoreValue = 0;

            //Assigns correct point value to each card
            switch (cardValue)
            {
                case "2":
                    {
                        scoreValue = 2;
                    }
                    break;

                case "3":
                    {
                        scoreValue = 3;
                    }
                    break;

                case "4":
                    {
                        scoreValue = 4;
                    }
                    break;

                case "5":
                    {
                        scoreValue = 5;
                    }
                    break;

                case "6":
                    {
                        scoreValue = 6;
                    }
                    break;

                case "7":
                    {
                        scoreValue = 7;
                    }
                    break;
                case "8":
                    {
                        scoreValue = 8;
                    }
                    break;

                case "9":
                    {
                        scoreValue = 9;
                    }
                    break;

                case "10":
                    {
                        scoreValue = 10;
                    }
                    break;

                case "Jack":
                case "Queen":
                case "King":
                    {
                        scoreValue = 12;
                    }
                    break;

                case "Ace":
                    {
                        scoreValue = 15;
                    }
                    break;
            }

            return scoreValue;
        }
    }
}
