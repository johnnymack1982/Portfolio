﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_6
{
    class Deck
    {
        //Private field for Deck class
        private List<Card> _cards;

        //Getter and setter for _cards field
        public List<Card> Cards
        {
            get
            {
                return _cards;
            }

            set
            {
                _cards = value;
            }
        }

        //Constructor method for Deck class
        public Deck()
        {
            //The deck is automatically populated by the program
            _cards = PopulateDeck();
        }

        //Custom method to automatically populate the deck
        private static List<Card> PopulateDeck()
        {
            //Initialize a new list of cards to be populated
            List<Card> cards = new List<Card>();

            //List of all card suits in the deck
            List<string> suits = new List<string>();
            suits.Add("Hearts");
            suits.Add("Spades");
            suits.Add("Clubs");
            suits.Add("Diamonds");

            //List of all card values in each suit
            List<string> values = new List<string>();
            values.Add("2");
            values.Add("3");
            values.Add("4");
            values.Add("5");
            values.Add("6");
            values.Add("7");
            values.Add("8");
            values.Add("9");
            values.Add("10");
            values.Add("Jack");
            values.Add("Queen");
            values.Add("King");
            values.Add("Ace");

            //For every suit, assign one card of each value to the deck
            foreach (string suit in suits)
            {
                foreach(string value in values)
                {
                    cards.Add(new Card(suit, value));
                }
            }

            //Return populated deck to the constructor method
            return cards;
        }
    }
}
