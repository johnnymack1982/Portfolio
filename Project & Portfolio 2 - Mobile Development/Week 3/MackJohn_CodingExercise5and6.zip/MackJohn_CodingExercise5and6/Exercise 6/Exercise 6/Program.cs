﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise_6
{
    class Program
    {
        static void Main(string[] args)
        {
            //Initialize instance of Program class for use when calling custom functions
            Program instance = new Program();

            //Initialize a new deck of cards
            Deck deck = new Deck();

            //Initialize a list of players to be populated at a later time
            List<Player> players = new List<Player>();

            //While this value is true the program will continue to run
            bool running = true;

            //Set custome background and text colors
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;

            //While the program is running the following code will continue to execute
            while (running)
            {
                //Keeps track of the current player
                int playerNumber = 1;

                //Loops until four players have been dealt
                while (playerNumber < 5)
                {
                    Console.Clear();

                    Console.WriteLine("EXERCISE 6: Card Counting and Points Awarding");

                    //Collect current player's name
                    string playerName = Validation.GetString($"\nPlease enter player {playerNumber}'s name." +
                          $"\nEnter 'Exit' to quit the program: ");

                    //If user entered "exit" the program will close
                    if (playerName.ToLower() == "exit")
                    {
                        running = false;
                        Utility.PauseBeforeContinuing();
                        Environment.Exit(0);
                    }

                    //Otherwise, the current player will receive a hand of cards
                    else
                    {
                        //Keeps track of the current card number
                        int cardNumber = 1;

                        //Used for selecting a random card from the deck
                        int randomCard = 0;
                        Random rand = new Random();

                        //Add a new player to the plaers list with no cards and no score
                        players.Add(new Player(playerName, new List<Card>(), 0));

                        //Continue to deal cards to the current player until they have 13 cards
                        while (cardNumber < 14)
                        {
                            //Selects a random card from the deck
                            randomCard = rand.Next(0, deck.Cards.Count - 1);

                            //Adds selected card to player's hand
                            players[playerNumber - 1].Hand.Add(deck.Cards[randomCard]);

                            //Adds the score value for the selected card to the player's total score
                            players[playerNumber - 1].Score += deck.Cards[randomCard].ScoreValue;

                            //Removes the selected card from the deck
                            deck.Cards.RemoveAt(randomCard);

                            //Increases the current card number
                            cardNumber++;
                        }

                        Console.Clear();

                        Console.WriteLine("EXERCISE 6: Card Counting and Points Awarding");

                        Console.WriteLine($"\nPlayer: {players[playerNumber - 1].Name}");
                        Console.WriteLine("\nHand:");

                        //Displays the suit and value for each card in the player's hand
                        foreach (Card card in players[playerNumber - 1].Hand)
                        {
                            Console.WriteLine($"\t{card.CardValue} of {card.CardSuit}");
                        }

                        Console.WriteLine($"\nPlayer Score = {players[playerNumber - 1].Score}");

                        //Increase player number
                        playerNumber++;

                        Utility.PauseBeforeContinuing();
                    }
                }

                //Sorts the players in order of score, from highest to lowest
                players.Sort((p, q) => p.Score.CompareTo(q.Score));
                players.Reverse();

                //Keeps track of the currently placed player
                int place = 1;

                //Keeps track of the place name for each player
                string placeName = null;

                //Keeps track of the total deck score (should be 420 by the end of the game)
                int deckScore = 0;

                Console.Clear();

                Console.WriteLine("EXERCISE 6: Card Counting and Points Awarding");

                //This code repeats for each player in the game
                foreach (Player player in players)
                {
                    //Selects the correct place name for the current player
                    switch (place)
                    {
                        case 1:
                            {
                                placeName = "First";
                            }
                            break;

                        case 2:
                            {
                                placeName = "Second";
                            }
                            break;

                        case 3:
                            {
                                placeName = "Third";
                            }
                            break;

                        case 4:
                            {
                                placeName = "Last";
                            }
                            break;
                    }

                    Console.WriteLine("\n-----------------------------------------");

                    Console.WriteLine($"\n{placeName} Place: {player.Name}");
                    Console.WriteLine("\nHand:");

                    //Displays card information for each card in the current player's hand
                    foreach (Card card in player.Hand)
                    {
                        Console.WriteLine($"\t{card.CardValue} of {card.CardSuit}");
                    }

                    Console.WriteLine($"\nPlayer Score: {player.Score}");

                    //Adds current player's score to the total deck score
                    deckScore += player.Score;

                    //Increases place to the next player
                    place++;
                }

                Console.WriteLine($"\nDeck Score: {deckScore}");

                //While this value is false, the program will be prevented from continuing
                bool selectionMade = false;

                //Do not continue until a valid selection has been made
                while (!selectionMade)
                {
                    string playAgain = Validation.GetString("\nWould you like to play again? (Yes / No): ");

                    switch (playAgain.ToLower())
                    {
                        //If player wants to play again, start the game over
                        case "yes":
                            {
                                selectionMade = true;
                                running = true;
                                deck = new Deck();
                                players = new List<Player>();
                            }
                            break;

                        //If player does not want to play again, the program will exit
                        case "no":
                            {
                                selectionMade = true;
                                running = false;
                                Utility.PauseBeforeContinuing();
                                Environment.Exit(0);
                            }
                            break;

                        //Prevents program from continuing until a valid selection has been made
                        default:
                            {
                                selectionMade = false;
                            }
                            break;
                    }
                }
            }
        }
    }
}
