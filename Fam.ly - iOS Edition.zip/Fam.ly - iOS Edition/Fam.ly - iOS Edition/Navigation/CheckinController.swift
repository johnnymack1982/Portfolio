//
//  CheckinController.swift
//  Fam.ly - iOS Edition
//
//  Created by Johnny Mack on 5/22/19.
//  Copyright © 2019 John Mack. All rights reserved.
//

import UIKit

class CheckinController: UIViewController {
    
    
    
    // UI Outlets
    @IBOutlet weak var findButton: UIButton!
    
    
    
    // System generated methods
    override func viewDidLoad() {
        super.viewDidLoad()

        findButton.isHidden = true
    }
}
